package edu.wlu.cs.levy.CG;

public class KDException extends Exception {
    protected KDException(String s) {
        super(s);
    }
    public static final long serialVersionUID = 1L;
}
